//
//  Triangulo.swift
//  Triangulos
//
//  Created by Alumno on 31/03/23.
//

import UIKit

class Triangulo: NSObject {
    var a: Int
    var b: Int
    var c: Int
    
    init(a: Int, b: Int, c: Int) {
        self.a = a
        self.b = b
        self.c = c
    }
    
    
    func calculoA()->Double{
        let calcS:Double = ((Double(self.a)+Double(self.b)+Double(self.c))/2)
        let calcA = sqrt(calcS*((calcS-Double(self.a))*(calcS-Double(self.b))*(calcS-Double(self.c))))
        return calcA
    }
    
    func tipoTriangulo()->String{
        
        if (self.a==self.b && self.b==self.c){
            return ("Equilatero")
        }else if(self.a==self.b || self.a==self.c || self.c==self.b){
            return("Isosceles")
        }else{
            return("Escaleno")
        }
    }
    
    func valid()->Bool {
        if (self.a+self.b>self.c){
            if(self.a+self.c>self.b){
                if (self.b+self.c>self.a){
                    return false
                }
            }
        }

        return true
        
    }
    

    
    

}
