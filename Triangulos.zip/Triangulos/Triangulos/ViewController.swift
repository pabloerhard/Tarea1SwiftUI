//
//  ViewController.swift
//  Triangulos
//
//  Created by Alumno on 31/03/23.
//

import UIKit




class ViewController: UIViewController {
    @IBOutlet weak var txtA: UITextField!
    
    @IBOutlet weak var txtB: UITextField!
    
    @IBOutlet weak var txtC: UITextField!
    
    @IBOutlet weak var imgTriangle: UIImageView!
    
    @IBOutlet weak var txtArea: UITextField!
    
    @IBOutlet weak var txtTipo: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    @IBAction func calculaArea(_ sender: UIButton) {
        if let a=Int(txtA.text!), let b=Int(txtB.text!),
           let c=Int(txtC.text!){
            
            let calculoA:Double = Triangulo(a: a, b: b, c: c).calculoA()
            txtArea.text = "\(calculoA)"
            let tipoTriangulo:String = Triangulo(a: a, b: b, c: c).tipoTriangulo()
            txtTipo.text = "\(tipoTriangulo)"
            
            if (tipoTriangulo=="Equilatero"){
                imgTriangle.image=UIImage(named:"Equilatero")
            } else if(tipoTriangulo=="Isosceles"){
                imgTriangle.image=UIImage(named:"Isosceles")
            } else{
                imgTriangle.image=UIImage(named:"Escaleno")
            }
            
            if (Triangulo(a: a, b: b, c: c).valid()){
                let alerta = UIAlertController(title: "Error", message: "Los campos son invalidos", preferredStyle: .alert)
                alerta.addAction(UIAlertAction(title: "Ok", style: .cancel))
                present(alerta, animated: true)
            }
            
           
            
        } else{
            let alerta = UIAlertController(title: "Error", message: "Los campos deben tener valor", preferredStyle: .alert)
            alerta.addAction(UIAlertAction(title: "Ok", style: .cancel))
            present(alerta, animated: true)
            
        }
        
    }
    
    @IBAction func quitaTeclado(_ sender: UITapGestureRecognizer) {
        view.endEditing(true)
    }
}

